<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>DDOS Protection - HostNext</title>
<meta name="description" content="description here">
<meta name="keywords" content="keywords here">
<!--[if lt IE 9]>  
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>  
<![endif]--> 
<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="screen">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/script.js"></script>
</head>

<body>
<!-- Topbar Start -->
<div class="header_with_image_wide"><!-- Imaged Banner Start Div --> 
<?php
include_once('inc/menu.php');
?>
<!-- Header End --> 
<!-- Banner Start --> 
	<div class="sub_banner_inner">
    	<h1>DDOS Protection</h1>
        <h2>We'll keep your website running. Guaranteed</h2>
    </div>
</div><!-- Imaged Banner End Div --> 
<!-- Banner End --

<!-- Content with para start -->
<div class="container_light_gray_wide">
	<div class="content_with_para_inside">
    	<h1>Managed cPanel VPS with Enterprise DDoS Protection</h1>
        <p>DDoS Protected Managed VPS packages come with cPanel and WHM (Web Host Manager) installed out of the box, which is pre-secured using our unique, in-house developed system. cPanel is the leading Linux control panel and allows you to manage almost every aspect of your server via an easy-to-use interface. Each VPS plan also comes with Softaculous pre-installed which has hundreds of scripts/software installations that you can choose from for use on your website(s).</p>
    </div>
</div>
<!-- Content with para end -->

<!-- Content with para start -->
<div class="container_blank_wide">
	<div class="ddos_main_mid">
    		<div class="ddos_heading">
            	<ul>
                <li>Disk Space</li>
                <li>Bandwidth</li>
                <li>Memory/RAM</li>
                <li>Enterprise Protection</li>
                <li>Monthly Price</li>
                <li>Order</li>
                </ul>
            </div>
            
            <div class="ddos_list">
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            	<ul>
                <li><span>Disk Space</span>60 GB - RAID Protected</li>
                <li><span>Bandwidth</span>2000 GB</li>
                <li><span>Memory/RAM</span>2GB Guaranteed</li>
                <li><span>Enterprise Protection</span>Up to 10Gbit</li>
                <li><span>Monthly Price</span>$32.00</li>
                <li><a href="#">Order Now</a></li>
                </ul>
            </div>
    </div>
</div>
<!-- Content with para end -->

<!-- Support Content Start -->
<div class="container_with_img_three">
		<div class="features_fourbyfour gray_txt_imp">
        	<h1>What Makes Us Better Than Our Competition</h1>
            <h3>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</h3>
            <ul>
            	<li>
                	<div class="features_details_innner">
                    	<img src="images/ddos_protection_icon.png" alt="ddos_protection_icon" />
                     	<h2>Enterprise DDoS Protection</h2>
                        <p>With our RioRey DDoS protection appliance we can block all DDoS attack types.</p>
                    </div>
                </li>

            	<li>
                	<div class="features_details_innner">
                    	<img src="images/multiple_location_icon.png" alt="multiple_location_icon" />
                    	<h2>Great Location</h2>
                        <p>Our DDoS protected VPS accounts are available in our Buffalo, New York datacenter. </p>
                    </div>
                </li>

            	<li>
                	<div class="features_details_innner">
                    	<img src="images/high_uptime_icon.png" alt="high_uptime_icon" />
                    	<h2>High Uptime Rates</h2>
                        <p>Our System is closely monitored for any threats & we make sure your VPS is always accessible.</p>
                    </div>
                </li>
            </ul>
        </div>
</div>
<!-- Support Content End -->

<!-- Footer Start -->

<!-- Footer Seprator Start -->
<?php
include_once('inc/footer.php');
?>
<!-- Footer End -->
	<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#ssl-tabs').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
    });
</script>
</body>

</html>
