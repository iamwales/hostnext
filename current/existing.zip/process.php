<?php
//header('Location: ' . $_SERVER['HTTP_REFERER']);

// basic package

if($_POST['plans']=="webh1")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=66&billingcycle=annually");

if($_POST['plans']=="webh2")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=66&billingcycle=biennially");

if($_POST['plans']=="webh3")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=66&billingcycle=triennially");


// standard package

if($_POST['plans']=="webh4")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=70&billingcycle=semiannually");


if($_POST['plans']=="webh5")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=70&billingcycle=annually");


if($_POST['plans']=="webh6")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=70&billingcycle=biennially");

if($_POST['plans']=="webh7")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=70&billingcycle=triennially");


//  Unlimited I


if($_POST['plans']=="webh8")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=59&billingcycle=monthly");

if($_POST['plans']=="webh9")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=59&billingcycle=semiannually");


if($_POST['plans']=="webh10")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=59&billingcycle=annually");


if($_POST['plans']=="webh11")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=59&billingcycle=biennially");


if($_POST['plans']=="webh12")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=59&billingcycle=triennially");


//  Unlimited II


if($_POST['plans']=="webh13")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=60&billingcycle=monthly");


if($_POST['plans']=="webh14")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=60&billingcycle=semiannually");


if($_POST['plans']=="webh15")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=60&billingcycle=annually");


if($_POST['plans']=="webh16")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=60&billingcycle=biennially");

if($_POST['plans']=="webh17")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=60&billingcycle=triennially");



//Business Hosting


// SD-5GB

if($_POST['plans']=="bh1")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=92&billingcycle=monthly");

if($_POST['plans']=="bh2")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=92&billingcycle=semiannually");


if($_POST['plans']=="bh3")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=92&billingcycle=annually");

if($_POST['plans']=="bh4")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=92&billingcycle=biennially");


if($_POST['plans']=="bh5")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=92&billingcycle=triennially");



// SD-10GB

if($_POST['plans']=="bh6")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=88&billingcycle=monthly");

if($_POST['plans']=="bh7")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=88&billingcycle=semiannually");


if($_POST['plans']=="bh8")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=88&billingcycle=annually");

if($_POST['plans']=="bh9")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=88&billingcycle=biennially");


if($_POST['plans']=="bh10")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=88&billingcycle=triennially");


// SD-25GB

if($_POST['plans']=="bh11")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=65&billingcycle=monthly");

if($_POST['plans']=="bh12")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=65&billingcycle=semiannually");


if($_POST['plans']=="bh13")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=65&billingcycle=annually");

if($_POST['plans']=="bh14")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=65&billingcycle=biennially");


if($_POST['plans']=="bh15")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=65&billingcycle=triennially");


// SD-50GB

if($_POST['plans']=="bh16")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=78&billingcycle=monthly");

if($_POST['plans']=="bh17")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=78&billingcycle=semiannually");


if($_POST['plans']=="bh18")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=78&billingcycle=annually");

if($_POST['plans']=="bh19")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=78&billingcycle=biennially");


if($_POST['plans']=="bh20")
header("Location: https://portal.hostnext.net/cart.php?a=add&pid=78&billingcycle=triennially");



?> 