<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Web Hosting - HostNext</title>
<meta name="description" content="description here">
<meta name="keywords" content="keywords here">
<!--[if lt IE 9]>  
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>  
<![endif]--> 
<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="screen">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/script.js"></script>
</head>

<body>
    
<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "03215100078", // WhatsApp number
            email: "sales@hostnext.net", // Email
            call_to_action: "Message us", // Call to action
            button_color: "#000000", // Color of button
            position: "right", // Position may be 'right' or 'left'
            order: "whatsapp,email", // Order of buttons
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget -->    
    
    
    
    
<!-- Topbar Start -->
<div class="header_with_image_wide"><!-- Imaged Banner Start Div --> 
<?php
include_once('inc/menu.php');
?>
<!-- Header End --> 
<!-- Banner Start --> 
	<div class="sub_banner_inner">
    	<h1>Virtual Private Servers</h1>
        <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in sodales sem.</h2>
    </div>
</div><!-- Imaged Banner End Div --> 
<!-- Banner End -->  

<!-- Content with para start -->
<div class="container_blank_wide">
<div class="containter_content_blank_center">
	<div class="typo_container_right" id="main_section_menu">
		<h2>Quick Links</h2>
     <ul>
     	<li><a href="#">Bank Transfer / Deposit</a></li>
        <li><a href="#">About Us</a></li>
        <li><a href="#">Policy</a></li>
        <li><a href="#">Terms Of Services</a></li>
        <li><a href="#">Demo Page 1</a></li>
        <li><a href="#">Demo Page 2</a></li>
        <li><a href="#">Demo Page 3</a></li>
        <li><a href="#">Demo Page 4</a></li>
        <li><a href="#">Demo Page 5</a></li>
        <li><a href="#">Demo Page 6</a></li>
        <li><a href="#">Demo Page 7</a></li>
        <li><a href="#">Demo Page 8</a></li>
     </ul>
    </div>
    
    
 
    
    <div class="typo_container_left">
 
 
 <p>Credit Cards, e-Wallets, Bank Transfer, Cash and Prepaid, Mobile and Phone You Choose!
QHoster is able to accept a wide variety of payment methods for hosting products and domain name registrations. Acceptable payment options are listed below.</p><br>
 
   
<h3>Standard Chartered</h3><br>
<p><img src="/images/standard_chartered_logo.png"align="right"></p>
<p>ACCOUNT TITLE: HostNext  Web Solutions </p>
<p>ACCOUNT #: 01178256401</p>
<p>BRANCH CODE : 108</p>
<p>IBAN: PK88SCBL0000001178256401</p><br><br></br>


<br>
<h3>Standard Chartered</h3><br>
<p><img src="/images/alfalah.png"align="right"></p>
<p><b>Account Title</b>: HostNext  Web Solutions </p>
<p><b>Account</b>: 01178256401</p>
<p>IBAN: PK88SCBL0000001178256401</p><br><br><br><br>

<h3></h3><br>
<p>After the payment please reply to the same invoice email which you received from us along with payment proof to process the order</p>





     
    </div>
		
</div>
</div>
<!-- Content with para end -->
<!-- Footer Start -->

<!-- Footer Seprator Start -->
<?php
include_once('inc/footer.php');
?>
<!-- Footer End -->
</body>

</html>
