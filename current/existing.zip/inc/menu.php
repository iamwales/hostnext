





<div class="container_top_bar_main">
	<div class="container_top_bar_inside">
    <p class="independence">Winter Offer is Here use this coupon: <strong>COUPON-123</strong> <a href="promotions">More Promotions</a></p>

    	<!--<ul> <li><i class=""></i> <a href="#" class="LiveHelpButton">Chat With Us Live</a></li></ul> -->




    
</div>
</div>
<!-- Topbar End -->
<!-- Header Start -->
<div class="container_front_main" id="menu">
	<div class="containter_front_wide_blank">
    	<div class="containter_mega_menu">
        <!-- mega menu start -->

<div class="Flat_mega_menu">
<i class="fa fa-bars"></i>			<!-- fontawesome mobile button icon -->
<input class="mobile_button" type="checkbox">		<!-- checkbox button for mobile to expand submenu -->

	<ul>

        <li><a href="index"><img src="images/logo.png" alt="logo"width="215"></a></li>
    	<li><a href="#">Web Hosting</a>
        	<ul class="submenu img_container"> 			<!-- submenu with image container -->
            	<li><label>cPanel Web Hosting </label><a href="webhosting"><img src="images/linux-icon.png" alt="linux-icon"></a><p>Great for personal sites and blogs.</p></li>
                <li><label>Windows Web Hosting</label><a href="windowshosting"><img src="images/windows-icon.png" alt="windows-icon"></a><p>Perfect for .NET-driven websites.</p></li>
                <li><label>Business Web Hosting</label><a href="businesshosting"><img src="images/business-icon.png" alt="business-icon"></a><p>Designed for uptime-critical sites.</p></li>
                <!--<li><label>WordPress Web Hosting</label><a href="wordpress-hosting"><img src="images/wordpress-icon.png" alt="wordpress-icon"></a><p>Create your own WordPress blog!</p></li>-->
            </ul>
        </li>
    	<li><a href="#">Resellers</a>
        	<ul class="submenu img_container"> 			<!-- submenu with image container -->
            	<li><label>Basic cPanel Reseller</label><a href="resellerhosting"><img src="images/reseller-linux-icon-basic.png" alt="reseller-linux-icon-basic"></a><p>Great for hosting multiple websites.</p></li>
               <!-- <li><label>Basic Windows Reseller</label><a href="#"><img src="images/reseller-windows-icon-basic.png" alt="reseller-windows-icon-basic"></a><p>For hosting multiple .NET websites.</p></li>-->

                <li><label>Business cPanel Reseller</label><a href="businessreseller"><img src="images/reseller-linux-icon-business.png" alt="reseller-linux-icon-business"></a><p>Great for hosting multiple uptime-critical websites.</p></li>
               <!-- <li><label>Business Windows Reseller</label><a href="#"><img src="images/reseller-windows-icon-business.png" alt="reseller-windows-icon-business"></a><p>Great for hosting multiple uptime-critical .NET websites.</p></li>-->
            </ul>
        </li>
    	<li><a href="#">Servers</a>
<ul class="submenu img_container"> 			<!-- submenu with image container -->
            	<li><label>Unmanaged VPS</label><a href="vps#openvz"><img src="images/vps_menu_icon.png" alt="vps_menu_icon"></a><p>Plans start at $4.99/ month</p></li>
                <li><label>Managed VPS</label><a href="#"><img src="images/vps_menu_icon.png" alt="vps_menu_icon"></a><p>Ultimate VPS Performance.</p></li>
                <li><label>Dedicated Servers</label><a href="dedicated"><img src="images/dedicated_menu_icon.png" alt="cloud_menu_icon"></a><p>Plans start at $89/ month</p></li>
                <li><label>Managed Dedicated Servers</label><a href="#"><img src="images/dedicated_menu_icon.png" alt="dedicated_menu_icon"></a><p>Plans start at $89/ month</p></li>
            </ul>
        </li>
    	<li><a href="#">Security</a>
        	<ul class="submenu img_container"> 			<!-- submenu with image container -->
            	<li><label>SSL Certificates</label><a href="#"><img src="images/ssl-menu-icon.png" alt="ssl-menu-icon"></a><p>A must-have for business websites.</p></li>
                <li><label>Malware scanner</label><a href="#"><img src="images/ddos_pro_icon_menu.png" alt="ddos_pro_icon_menu"></a><p>Malware, Trojan and Vulnerability Scanner.</p></li>
                <li><label>Remote Backups</label><a href="#"><img src="images/menu_spam_expert_icon.png" alt="menu_spam_expert_icon"></a><p>Continuous Data Protection with R1soft.</p></li>
                <li><label>Domain ID Protection</label><a href="#"><img src="images/whois_privacy_icon.png" alt="whois_privacy_icon"></a><p>Protect your WHOIS info from ID theft, spam and more!</p></li>
            </ul>
        </li>
    	<li><a href="#">Company</a>
        	<ul class="submenu one_col">			<!-- submenu with one column -->
            	<li><a href="aboutus">About</a></li>
                <li><a href="#">Our Difference</a></li>
                <li><a href="#">Our Customers</a></li>
                <li><a href="#">Hot Deals</a></li>
                <li><a href="#">Announcements</a></li>
                <li><a href="#">Careers</a></li>
            </ul>
        </li>

    	

<li class="user_login"><i class="fa fa-user"></i><a href="#">Contact us</a>	<!-- login bar form -->
        	<ul>
            	<form method="post" action="https://portal.hostnext.net/dologin.php">
                	<table>
                    	<tr>
                        	<td>Email Address:</td>
                        </tr>
                        <tr>
                        	<td><input type="text" name="username" required ></td>
                        </tr>
                        <tr>
                        	<td>Password</td>
                        </tr>
                        <tr>
                        	<td><input type="password" name="password" required ></td>
                        </tr>
                        <tr>
                        	<td><input type="submit" value="Login"></td>
                        </tr>
                    </table>
                </form>
            </ul>
        </li>








    </ul>
</div>

<!-- mega menu end -->
        </div>
     </div>
</div>
<script type="text/javascript" src="js/nagging-menu.js" charset="utf-8"></script>