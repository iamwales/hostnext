<div class="cls0">        
        <div class="domain_pricing_list">
        	<ul>
            	<li><span>TLD</span>.com</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.net <label>new</label></li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.net</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.info</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.org</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.biz</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.tel <label>new</label></li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.asia</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.mobi <label>new</label></li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.co</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        	<ul>
            	<li><span>TLD</span>.in</li> <li><span>Duration</span>4 Years</li> <li><span>Registration</span>$40</li> <li><span>Renewal</span>$40.45</li> <li><span>Transfer</span>$40.33</li> 
            </ul>
        </div>
</div>