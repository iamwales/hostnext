<div class="container_blank_wide">
 	<div class="reviews_inside_main">
    <h2>Our Customers <strong>love</strong> us!</h2>
    	<ul>
        	<li>
            <p>We have been working with HostNext since June 2007. Its  worth  experience  working with an esteemed company as HostNext. We found  almost no down time during this period, and customer support is one of the specialty to choose HostNext as our hosting service provider.</p>
            <h5>Raza -Solutionz247</h5>
            </li>
        	<li>
            <p>HostNext is unquestionably the best value for your money. It has many features and advantages than other hosting company we have used in the past. We recommend HostNext 100%. Although their phone support may be weak it is compensated by their superb and prompt response via email, online support and instant message. As web developers our company needs to count on a reliable hosting service, and after a dozen of accounts we are hosting with HostNext we have found a dependable and profitable business!! </p>
            <h5>Makabu Pvt Ltd</h5>
            </li>

</ul>




    </div>   
</div>